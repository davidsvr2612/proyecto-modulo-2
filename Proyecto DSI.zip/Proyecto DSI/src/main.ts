import { platformBrowser }    from '@angular/platform-browser';
import { AppModule }          from './app/app-module';

import { AirbnbApiService }   from './app/services/AirbnbApiService';

// Bootstrap de Angular
platformBrowser().bootstrapModule(AppModule).then((moduleRef) => 
{
    console.log('✅ Angular inicializado correctamente');
    
    // Obtenemos el servicio del inyector de Angular
    const alojamientoService = moduleRef.injector.get(AirbnbApiService);
    
    // Ejecutamos las pruebas de API
    ejecutarPruebasAPI(alojamientoService);
})
.catch(err => console.error('❌ Error al inicializar Angular:', err));



// Función para ejecutar las pruebas de API
async function ejecutarPruebasAPI(airbnbApiService: AirbnbApiService) 
{
  console.log('\n🚀 ==========================================');
  console.log('🚀 Iniciando pruebas de API de Alojamiento');
  console.log('🚀 ==========================================\n');

  // Prueba 1: Alojamiento en Indonesia
  const busquedaIndonesia = {
    listing_id  : '1633199196629299212',
    checkin     : '2026-09-01',
    checkout    : '2026-09-05',
    adults      : 2,
    children    : 0,
    infants     : 0,
    pets        : 0,
    currency    : 'IDR',
  };

  // Prueba 2: Alojamiento en Nueva York
  const busquedaNuevaYork = {
    listing_id: '987654321',
    checkin:    '2026-12-20',
    checkout:   '2026-12-27',
    adults:     1,
    currency:   'USD',
  };

  // Simulamos el click para hacer el llamado a la API
  try 
  {
    console.log('\n📍 PRUEBA 1: Alojamiento en Indonesia');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    const resultadoBali = await airbnbApiService.getListingDetails(busquedaIndonesia);

    console.log('\n✅ Datos completos recibidos de Indonesia:');
    console.log(JSON.stringify(resultadoBali, null, 2));

  } 
  catch (error: any) {
    console.error('\n💥 Error en la prueba de Indonesia:', error.message);
  }

  // Simulamos el click para hacer el llamado a la API
  try 
  {
    console.log('\n\n📍 PRUEBA 2: Alojamiento en Nueva York');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    const resultadoNY = await airbnbApiService.getListingDetails(busquedaNuevaYork);
    console.log('\n✅ Datos completos recibidos de Nueva York:');
    console.log(JSON.stringify(resultadoNY, null, 2));

  } 
  catch (error: any) {
    console.error('\n💥 Error en la prueba de Nueva York:', error.message);
  }

  console.log('\n🏁 ==========================================');
  console.log('🏁 Pruebas de API completadas');
  console.log('🏁 ==========================================\n');
  
}
