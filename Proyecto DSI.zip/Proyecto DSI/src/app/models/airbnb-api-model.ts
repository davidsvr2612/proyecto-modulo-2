import { InjectionToken } from '@angular/core';


// Representa la estructura para mapear la configuración base del API
export interface BaseApiConfig 
{
  token   : string;
  baseUrl?: string;
}

// ********************* METODO LISTING DETAILS DEL API AIRBNB  ********************* 

// Representa los campos que se necesitan enviar para listar los alojamientos disponibles 
// en el API
// Esto es un DTO
export interface RequestListingDetailsModel {
  listing_id  : string;
  checkin     : string;
  checkout    : string;
  adults      : number;
  children?   : number;
  infants?    : number;
  pets?       : number;
  currency?   : string;
}

// Representa los campos que retorna la respuesta de la API
// Esto es un DTO
export interface ResponseListingDetailModel {
  listing_id? : string;
  title?      : string;
  price?      : number;
  currency?   : string;
  available?  : boolean;
  // Agrega más campos según la respuesta real de la API
  [key: string]: any; // Permite propiedades adicionales
}


// ********************* METODO PARA BUSCAR ALOJAMIENTOS  ********************* 

export interface SearchRequest 
{
  
}

// Creamos el InjectionToken que Angular usará para resolver la dependencia
export const BASE_API_CONFIG = new InjectionToken<BaseApiConfig>('baseapi.config');
