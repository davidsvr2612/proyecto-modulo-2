import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule }    from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing-module';
import { HttpClientModule } from '@angular/common/http';
import { Iniciocomponent }  from './components/iniciocomponent/iniciocomponent';
import { AppComponent }     from './app';

import { BASE_API_CONFIG } from './models/airbnb-api-model';

@NgModule({
  imports: [BrowserModule, AppRoutingModule, HttpClientModule],
  providers: [
    provideBrowserGlobalErrorListeners(),
    // Proveemos el valor concreto para CLIENT_CONFIG
    {
      provide: BASE_API_CONFIG,
      useValue: {
        token: 'apify_api_hkwOYHW5jxoqXj9CEEpyB56e0SpgYC479ze3',
        baseUrl: 'https://romy--airbnb-all-in-one-api.apify.actor'
      }
    }
  ],
  declarations: [AppComponent, Iniciocomponent],
  bootstrap: [AppComponent]
})
export class AppModule {}
